
const products = [
    { id: 1, name: "BioG Standard Cylinder", price: 50 },
    { id: 2, name: "BioG Premium Cylinder", price: 75 },
    { id: 3, name: "BioG Deluxe Cylinder", price: 100 }
];


function displayProducts() {
    const productsContainer = document.getElementById("products");
    productsContainer.innerHTML = "";
    
    products.forEach(product => {
        const productElement = document.createElement("div");
        productElement.classList.add("product");
        productElement.innerHTML = `
            <h3>${product.name}</h3>
            <p>Price: $${product.price}</p>
            <button onclick="addToCart(${product.id})">Add to Cart</button>
        `;
        productsContainer.appendChild(productElement);
    });
}

// Function to add a product to the cart (dummy function for now)
function addToCart(productId) {
    alert(`Product with ID ${productId} added to cart.`);
}

// Display products when the page loads
displayProducts();
